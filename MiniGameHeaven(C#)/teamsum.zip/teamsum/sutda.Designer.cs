﻿namespace teamsum
{
    partial class sutda
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.start = new System.Windows.Forms.Button();
            this.tbWinner = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.tbMoney = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tbPcoin = new System.Windows.Forms.TextBox();
            this.tbDcoin = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btnDie = new System.Windows.Forms.Button();
            this.btnCheck = new System.Windows.Forms.Button();
            this.btnCall = new System.Windows.Forms.Button();
            this.tbPlayer = new System.Windows.Forms.TextBox();
            this.tbDealer = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.gameToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.settingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ppb2 = new System.Windows.Forms.PictureBox();
            this.ppb1 = new System.Windows.Forms.PictureBox();
            this.dpb2 = new System.Windows.Forms.PictureBox();
            this.dpb1 = new System.Windows.Forms.PictureBox();
            this.infoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ppb2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ppb1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dpb2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dpb1)).BeginInit();
            this.SuspendLayout();
            // 
            // start
            // 
            this.start.Location = new System.Drawing.Point(403, 84);
            this.start.Name = "start";
            this.start.Size = new System.Drawing.Size(158, 31);
            this.start.TabIndex = 57;
            this.start.Text = "start";
            this.start.UseVisualStyleBackColor = true;
            this.start.Click += new System.EventHandler(this.start_Click);
            // 
            // tbWinner
            // 
            this.tbWinner.Enabled = false;
            this.tbWinner.Location = new System.Drawing.Point(407, 131);
            this.tbWinner.Name = "tbWinner";
            this.tbWinner.Size = new System.Drawing.Size(155, 25);
            this.tbWinner.TabIndex = 56;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(350, 134);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(47, 15);
            this.label6.TabIndex = 55;
            this.label6.Text = "승자 :";
            // 
            // tbMoney
            // 
            this.tbMoney.Enabled = false;
            this.tbMoney.Location = new System.Drawing.Point(407, 162);
            this.tbMoney.Name = "tbMoney";
            this.tbMoney.Size = new System.Drawing.Size(155, 25);
            this.tbMoney.TabIndex = 54;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(350, 165);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(47, 15);
            this.label5.TabIndex = 53;
            this.label5.Text = "판돈 :";
            // 
            // tbPcoin
            // 
            this.tbPcoin.Enabled = false;
            this.tbPcoin.Location = new System.Drawing.Point(408, 558);
            this.tbPcoin.Name = "tbPcoin";
            this.tbPcoin.Size = new System.Drawing.Size(155, 25);
            this.tbPcoin.TabIndex = 52;
            // 
            // tbDcoin
            // 
            this.tbDcoin.Enabled = false;
            this.tbDcoin.Location = new System.Drawing.Point(407, 285);
            this.tbDcoin.Name = "tbDcoin";
            this.tbDcoin.Size = new System.Drawing.Size(155, 25);
            this.tbDcoin.TabIndex = 51;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(350, 561);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(47, 15);
            this.label4.TabIndex = 50;
            this.label4.Text = "Coin :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(350, 288);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(47, 15);
            this.label3.TabIndex = 49;
            this.label3.Text = "Coin :";
            // 
            // btnDie
            // 
            this.btnDie.Location = new System.Drawing.Point(353, 463);
            this.btnDie.Name = "btnDie";
            this.btnDie.Size = new System.Drawing.Size(210, 52);
            this.btnDie.TabIndex = 48;
            this.btnDie.Text = "다이";
            this.btnDie.UseVisualStyleBackColor = true;
            this.btnDie.Click += new System.EventHandler(this.btnDie_Click);
            // 
            // btnCheck
            // 
            this.btnCheck.Location = new System.Drawing.Point(353, 405);
            this.btnCheck.Name = "btnCheck";
            this.btnCheck.Size = new System.Drawing.Size(210, 52);
            this.btnCheck.TabIndex = 47;
            this.btnCheck.Text = "체크";
            this.btnCheck.UseVisualStyleBackColor = true;
            this.btnCheck.Click += new System.EventHandler(this.btnCheck_Click);
            // 
            // btnCall
            // 
            this.btnCall.Location = new System.Drawing.Point(353, 347);
            this.btnCall.Name = "btnCall";
            this.btnCall.Size = new System.Drawing.Size(210, 52);
            this.btnCall.TabIndex = 46;
            this.btnCall.Text = "콜";
            this.btnCall.UseVisualStyleBackColor = true;
            this.btnCall.Click += new System.EventHandler(this.btnCall_Click);
            // 
            // tbPlayer
            // 
            this.tbPlayer.Enabled = false;
            this.tbPlayer.Location = new System.Drawing.Point(115, 316);
            this.tbPlayer.Name = "tbPlayer";
            this.tbPlayer.Size = new System.Drawing.Size(447, 25);
            this.tbPlayer.TabIndex = 41;
            // 
            // tbDealer
            // 
            this.tbDealer.Enabled = false;
            this.tbDealer.Location = new System.Drawing.Point(115, 43);
            this.tbDealer.Name = "tbDealer";
            this.tbDealer.Size = new System.Drawing.Size(447, 25);
            this.tbDealer.TabIndex = 40;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(61, 319);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(48, 15);
            this.label2.TabIndex = 39;
            this.label2.Text = "Player";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(61, 46);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(48, 15);
            this.label1.TabIndex = 38;
            this.label1.Text = "Dealer";
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.gameToolStripMenuItem,
            this.infoToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(579, 28);
            this.menuStrip1.TabIndex = 58;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // gameToolStripMenuItem
            // 
            this.gameToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.settingToolStripMenuItem});
            this.gameToolStripMenuItem.Name = "gameToolStripMenuItem";
            this.gameToolStripMenuItem.Size = new System.Drawing.Size(61, 24);
            this.gameToolStripMenuItem.Text = "Game";
            // 
            // settingToolStripMenuItem
            // 
            this.settingToolStripMenuItem.Name = "settingToolStripMenuItem";
            this.settingToolStripMenuItem.Size = new System.Drawing.Size(132, 26);
            this.settingToolStripMenuItem.Text = "Setting";
            this.settingToolStripMenuItem.Click += new System.EventHandler(this.settingToolStripMenuItem_Click);
            // 
            // ppb2
            // 
            this.ppb2.Image = global::teamsum.Properties.Resources.back;
            this.ppb2.Location = new System.Drawing.Point(184, 347);
            this.ppb2.Name = "ppb2";
            this.ppb2.Size = new System.Drawing.Size(147, 236);
            this.ppb2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ppb2.TabIndex = 45;
            this.ppb2.TabStop = false;
            // 
            // ppb1
            // 
            this.ppb1.Image = global::teamsum.Properties.Resources.back;
            this.ppb1.Location = new System.Drawing.Point(17, 347);
            this.ppb1.Name = "ppb1";
            this.ppb1.Size = new System.Drawing.Size(147, 236);
            this.ppb1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ppb1.TabIndex = 44;
            this.ppb1.TabStop = false;
            // 
            // dpb2
            // 
            this.dpb2.Image = global::teamsum.Properties.Resources.back;
            this.dpb2.InitialImage = null;
            this.dpb2.Location = new System.Drawing.Point(184, 74);
            this.dpb2.Name = "dpb2";
            this.dpb2.Size = new System.Drawing.Size(147, 236);
            this.dpb2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.dpb2.TabIndex = 43;
            this.dpb2.TabStop = false;
            // 
            // dpb1
            // 
            this.dpb1.ErrorImage = null;
            this.dpb1.Image = global::teamsum.Properties.Resources.back;
            this.dpb1.Location = new System.Drawing.Point(17, 74);
            this.dpb1.Name = "dpb1";
            this.dpb1.Size = new System.Drawing.Size(147, 236);
            this.dpb1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.dpb1.TabIndex = 42;
            this.dpb1.TabStop = false;
            // 
            // infoToolStripMenuItem
            // 
            this.infoToolStripMenuItem.Name = "infoToolStripMenuItem";
            this.infoToolStripMenuItem.Size = new System.Drawing.Size(48, 24);
            this.infoToolStripMenuItem.Text = "Info";
            this.infoToolStripMenuItem.Click += new System.EventHandler(this.infoToolStripMenuItem_Click);
            // 
            // sutda
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(579, 614);
            this.Controls.Add(this.start);
            this.Controls.Add(this.tbWinner);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.tbMoney);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.tbPcoin);
            this.Controls.Add(this.tbDcoin);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnDie);
            this.Controls.Add(this.btnCheck);
            this.Controls.Add(this.btnCall);
            this.Controls.Add(this.ppb2);
            this.Controls.Add(this.ppb1);
            this.Controls.Add(this.dpb2);
            this.Controls.Add(this.dpb1);
            this.Controls.Add(this.tbPlayer);
            this.Controls.Add(this.tbDealer);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.Name = "sutda";
            this.Text = "sutda";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.sutda_FormClosed);
            this.Load += new System.EventHandler(this.sutda_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ppb2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ppb1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dpb2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dpb1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.Button start;
        private System.Windows.Forms.TextBox tbWinner;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tbMoney;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tbPcoin;
        private System.Windows.Forms.TextBox tbDcoin;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnDie;
        private System.Windows.Forms.Button btnCheck;
        private System.Windows.Forms.Button btnCall;
        private System.Windows.Forms.PictureBox ppb2;
        private System.Windows.Forms.PictureBox ppb1;
        private System.Windows.Forms.PictureBox dpb2;
        private System.Windows.Forms.PictureBox dpb1;
        private System.Windows.Forms.TextBox tbPlayer;
        private System.Windows.Forms.TextBox tbDealer;
        public System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem gameToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem settingToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem infoToolStripMenuItem;
    }
}