﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace teamsum
{
    public class GameObject
    {
        public OBJECT_TYPE type;

        public Bitmap bitmap;
        public float x, y;
        public float vx, vy;
        public int width;
        public int height;
    }
}